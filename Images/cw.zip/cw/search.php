<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="icon" href="Images/logo.jpg">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<header>
			<table class="header1">
				<tr>
					<td class="moviehut"><a href="index.html">Movie <br>Hut</a></td>
					<td class="menue">Catalog</td>
					<td class="menue">Support</td>
					<td class="menue">Contact</td>
					<td class="login"><a href="Login.html"> Login</a></td>
					<td class="reg"><a href="Register.html">Register</a></td>
				</tr>
			</table>
		</header>
		<br>
		<br>
		<form action="search.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
<?php
$servername = "localhost";
$username = 'root';
$password ="123";
$dbname="moviehut";
$conn=new mysqli("localhost",'root',"123","moviehut");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM films ";
$search_value = '';
if(isset($_GET['search'])){
	$search_value=$_GET["search"];
	$sql .= ' WHERE fname like "%'.$search_value.'%"';
}
$result = $conn->query($sql);

?>	
<ul>
<?php 
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo  "<li>" . $row["Film_code"]. " - Name: " . $row["fname"]. " " . $row["film_type"]. "</li>";
	   
	 }
 
}else {
    echo "<li>No records</li>";
}
$conn->close();
?>

</ul>
 
		
</body>
</html>