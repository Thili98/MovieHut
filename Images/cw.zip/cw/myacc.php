<!DOCTYPE html>
<html>
	<head>
	<link rel="stylesheet" type="text/css" href="style1.css">
		<link rel="icon" href="Images/logo.jpg">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>

		<header>
			<table class="header1">
				<tr>
					<td class="moviehut"><a href="index.html">Movie <br>Hut</a></td>
					<td class="menue">Catalog</td>
					<td class="menue">Support</td>
					<td class="menue">Contact</td>
					<td class="menue">My Account</td>
					
				</tr>
			</table>
		</header>
		<?php
				$servername = "localhost";
				$username = 'root';
				$password ="123";
				$dbname="moviehut";
				$conn=new mysqli("localhost",'root',"123","moviehut");
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
				
				if(isset($_GET['delete'])){
					$sql_update = "DELETE from films WHERE Film_code=".$_GET["delete"];
					
					if (!mysqli_query($conn, $sql_update)) {
						echo "Error: " . $sql_update . "<br>" . mysqli_error($conn);
					}else{
						header("Location: http://localhost:8081/cw/myacc.php"); /* Redirect browser */
						exit();
					}						
				
				}

				$sql = "SELECT * FROM films WHERE fname = '112212' ";
				$search_value = '';
				if(isset($_GET['search'])){
					$search_value=$_GET["search"];
					$sql = 'SELECT * FROM films WHERE fname = "'.$search_value.'"';
				}
				$result = $conn->query($sql);

		?>	
		
		<div class="content">
			<div class="search_panel">
				<form action="myacc.php" style="text-align: right;padding-top: 10px;padding-right : 50px;">
				  <input type="text" placeholder="Search.." name="search" value="<?php echo $search_value; ?>" />
				  <button type="submit"><i class="fa fa-search"></i></button>
				</form>
			</div>
			<div class="profile">
				<?php 
					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							
							
						
				?>			
				<div class="film_name">
					<h1><?php  echo $row["fname"] ?></h1>
				</div>
				
				<div>
					<div class="image" align="middle" ><img src="<?php  echo $row["image"] ?>" border = "5"/></div>
					<div class="desc">
						<h2>Story</h2>
						<p><?php  echo $row["description"] ?></p>
						<h4>Type :- <span><?php  echo $row["film_type"] ?></span></h4>
						<a href="updatefilm.php?id=<?php echo $row["Film_code"] ?>" ><i>Update</i></a> <span style="color:white">/</span> <a href="myacc.php?delete=<?php echo $row["Film_code"] ?>"><i>Delete</i></a>
					</div>
				</div>
					
				<?php 
							
							break;
						}
					 
					}else{
				?>
						<div class="empty_page">
							<h2>no film found.! </h2>
							<h5>search film by name</h5>
						</div>
				<?php 
					}

				$conn->close(); 
				?>
				
			</div>
		</div>
	</body>
</<html>
 