<!DOCTYPE html>
<html>
	<head>
	<link rel="stylesheet" type="text/css" href="style1.css">
		<link rel="icon" href="Images/logo.jpg">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>

		<header>
			<table class="header1">
				<tr>
					<td class="moviehut"><a href="index.html">Movie <br>Hut</a></td>
					<td class="menue">Catalog</td>
					<td class="menue">Support</td>
					<td class="menue">Contact</td>
					<td class="menue">My Account</td>
					
				</tr>
			</table>
		</header>
		<?php
				$servername = "localhost";
				$username = 'root';
				$password ="123";
				$dbname="moviehut";
				$conn=new mysqli("localhost",'root',"123","moviehut");
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
				
				
				if(isset($_POST['save'])){
					$sql_update = "UPDATE films SET fname='".$_POST['film_name']."',film_type='".$_POST['film_type']."',description='".$_POST['film_desc']."' WHERE Film_code=".$_REQUEST["id"];
					
					if (!mysqli_query($conn, $sql_update)) {
						echo "Error: " . $sql_update . "<br>" . mysqli_error($conn);
					}else{
						header("Location: http://localhost:8081/cw/myacc.php?search=".$_POST['film_name']); /* Redirect browser */
						exit();
					}						
				
				}

				
    
				$sql = "SELECT * FROM films WHERE fname = '' ";
				$search_value = '';
				if(isset($_REQUEST['id'])){
					$search_value=$_REQUEST["id"];
					$sql = 'SELECT * FROM films WHERE Film_code = "'.$search_value.'"';
				}
				$result = $conn->query($sql);
				
				

		?>	
		
		<div class="content">
			<div class="profile">
				<form action="updatefilm.php?id=<?php echo $_REQUEST['id'] ?>" method="POST">
					<?php 
						if ($result->num_rows > 0) {
							// output data of each row
							while($row = $result->fetch_assoc()) {
								
							
					?>	
						
					<div class="edit_name" align="center">
						<label>Name</label>
						<input type="text" name="film_name" value="<?php  echo $row["fname"] ?>"/>
					</div>
					<div class="edit_type" align="center">
						<label>Type</label>
						<input type="text" name="film_type" value="<?php  echo $row["film_type"] ?>"/>
					</div>
					<div class="edit_desc" align="center">
						<label>Description</label>
						<textarea name="film_desc" rows="6"><?php  echo $row["description"] ?></textarea>
					</div>
					<div class="edit_btn" align="center">
						<input type="submit" name="save" value="Save"/>
					</div>
				</form>
				<?php 
							
							
						}
					 
					}

				$conn->close(); 
				?>
				
			</div>
		</div>
	</body>
</<html>
 